import 'package:flutter/material.dart';
import 'main3.dart'; // Import Main3 page

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.light().copyWith(
        scaffoldBackgroundColor: const Color(0xFFFDF8F8),
      ),
      home: const TeamSetupPage(),
    );
  }
}

class TeamSetupPage extends StatefulWidget {
  const TeamSetupPage({super.key});

  @override
  State<TeamSetupPage> createState() => _TeamSetupPageState();
}

class _TeamSetupPageState extends State<TeamSetupPage> {
  int numberOfwords = 3;
  int numberOfTeams = 2; // Default number of teams
  int numberOfPlayers = 4; // Default number of players
  double sayWhatSlider = 0; // Default value for "SAY WHAT?" slider
  double pantomimeSlider = 0; // Default value for "PANTOMIME" slider
  double oneWordSlider = 0; // Default value for "ONE WORD" slider

  void _navigateToMain3(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Main3(numberOfTeams: numberOfTeams),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              children: [
                const SizedBox(height: 20),
                // NUMBER OF TEAMS Counter
                CustomCounterWidget(
                  labelText: "NUMBER OF TEAMS",
                  minValue: 2,
                  maxValue: 6,
                  initialValue: numberOfTeams,
                  onCounterChanged: (newValue) {
                    setState(() {
                      numberOfTeams = newValue;
                    });
                  },
                ),
                const SizedBox(height: 20),
                // NUMBER OF PLAYERS Counter
                CustomCounterWidget(
                  labelText: "NUMBER OF PLAYERS",
                  minValue: 4,
                  maxValue: 16,
                  initialValue: numberOfPlayers,
                  onCounterChanged: (newValue) {
                    setState(() {
                      numberOfPlayers = newValue;
                    });
                  },
                ),
                const SizedBox(height: 20),
                // NUMBER OF WORDS Counter
                CustomCounterWidget(
                  labelText: "NUMBER OF WORDS",
                  minValue: 3,
                  maxValue: 4,
                  initialValue: numberOfwords,
                  onCounterChanged: (newValue) {
                    setState(() {
                      numberOfwords = newValue;
                    });
                  },
                ),
                const SizedBox(height: 20),
                
                // SAY WHAT? Slider
                CustomSliderWidget(
                  labelText: "SAY WHAT?",
                  minValue: 0,
                  maxValue: 160,
                  stepSize: 10,
                  initialValue: sayWhatSlider,
                  onSliderChanged: (newValue) {
                    setState(() {
                      sayWhatSlider = newValue;
                    });
                  },
                ),
                const SizedBox(height: 20),
                // PANTOMIME Slider
                CustomSliderWidget(
                  labelText: "PANTOMIME",
                  minValue: 0,
                  maxValue: 160,
                  stepSize: 10,
                  initialValue: pantomimeSlider,
                  onSliderChanged: (newValue) {
                    setState(() {
                      pantomimeSlider = newValue;
                    });
                  },
                ),
                const SizedBox(height: 20),
                // ONE WORD Slider
                CustomSliderWidget(
                  labelText: "ONE WORD",
                  minValue: 0,
                  maxValue: 160,
                  stepSize: 10,
                  initialValue: oneWordSlider,
                  onSliderChanged: (newValue) {
                    setState(() {
                      oneWordSlider = newValue;
                    });
                  },
                ),
                const SizedBox(height: 40),
                // NEXT Button
                GestureDetector(
                  onTap: () => _navigateToMain3(context),
                  child: Container(
                    width: 200,
                    height: 60,
                    decoration: BoxDecoration(
                      color: const Color(0xFF30B0C7),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: const Center(
                      child: Text(
                        "NEXT",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// Custom Counter Widget
class CustomCounterWidget extends StatefulWidget {
  final String labelText;
  final int minValue;
  final int maxValue;
  final int initialValue;
  final ValueChanged<int> onCounterChanged;

  const CustomCounterWidget({
    super.key,
    required this.labelText,
    required this.minValue,
    required this.maxValue,
    required this.initialValue,
    required this.onCounterChanged,
  });

  @override
  State<CustomCounterWidget> createState() => _CustomCounterWidgetState();
}

class _CustomCounterWidgetState extends State<CustomCounterWidget> {
  late int counter;

  @override
  void initState() {
    super.initState();
    counter = widget.initialValue;
  }

  void _decreaseCounter() {
    if (counter > widget.minValue) {
      setState(() {
        counter--;
        widget.onCounterChanged(counter);
      });
    }
  }

  void _increaseCounter() {
    if (counter < widget.maxValue) {
      setState(() {
        counter++;
        widget.onCounterChanged(counter);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 80,
      decoration: BoxDecoration(
        color: const Color(0xFFD9D9D9),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              widget.labelText,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          Row(
            children: [
              GestureDetector(
                onTap: _decreaseCounter,
                child: const Icon(Icons.remove, color: Colors.purple, size: 28),
              ),
              const SizedBox(width: 10),
              Text(
                counter.toString(),
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(width: 10),
              GestureDetector(
                onTap: _increaseCounter,
                child: const Icon(Icons.add, color: Colors.purple, size: 28),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// Slider Widget
class CustomSliderWidget extends StatelessWidget {
  final String labelText;
  final double minValue;
  final double maxValue;
  final double stepSize;
  final double initialValue;
  final ValueChanged<double> onSliderChanged;

  const CustomSliderWidget({
    super.key,
    required this.labelText,
    required this.minValue,
    required this.maxValue,
    required this.stepSize,
    required this.initialValue,
    required this.onSliderChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          labelText,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        Slider(
          value: initialValue,
          min: minValue,
          max: maxValue,
          divisions: ((maxValue - minValue) / stepSize).round(),
          onChanged: onSliderChanged,
        ),
      ],
    );
  }
}
